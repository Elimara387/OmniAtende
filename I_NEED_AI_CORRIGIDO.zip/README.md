# OmniAtende
Plataforma de atendimento multicanal com IA integrada.

## Como executar
Instale as dependências:
```bash
npm install
```
Inicie o servidor:
```bash
npm start
```
O frontend ficará disponível em `http://localhost:3000`.
