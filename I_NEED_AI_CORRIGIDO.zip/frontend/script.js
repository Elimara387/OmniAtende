document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('toggleMode');
  const vendas = document.getElementById('vendas');
  const pedidos = document.getElementById('pedidos');
  const lista = document.getElementById('lista-atendimentos');

  toggle.addEventListener('click', () => {
    alert('Alternando entre IA e humano...');
  });

  // Simula dados
  vendas.textContent = 'R$ 110';
  pedidos.textContent = '8';
  const atendimentos = ['Pedido 001 - Concluído', 'Pedido 002 - Em andamento', 'Pedido 003 - Cancelado'];

  atendimentos.forEach(at => {
    const li = document.createElement('li');
    li.textContent = at;
    lista.appendChild(li);
  });
});
